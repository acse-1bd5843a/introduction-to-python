"""Module of integrations with other services"""
