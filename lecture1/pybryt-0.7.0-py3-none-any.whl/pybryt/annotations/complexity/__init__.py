"""Annotation scaffold for asserting the complexity of code"""

from . import complexities
from .annotation import *
