"""Alias for ``pybryt.annotations.complexity.complexities``"""

from .annotations.complexity.complexities import *
