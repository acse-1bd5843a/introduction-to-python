"""Alias for ``pybryt.annotations.invariants``"""

from .annotations.invariants import *
